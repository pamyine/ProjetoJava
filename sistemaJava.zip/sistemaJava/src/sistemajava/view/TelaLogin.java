
package sistemajava.view;


import sistemajava.dao.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import sistemajava.view.TelaPrincipal;



public class TelaLogin extends javax.swing.JFrame 
{   private int tentativasLogin = 0;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaLogin.class.getName());

    
    public TelaLogin() 
    {
        initComponents();
        txtUsuario.setToolTipText("Digite seu nome de usuário (mínimo 3 caracteres)");
        txtSenha.setToolTipText("Digite sua senha (mínimo 3 caracteres)");
    
        // Focar no campo usuário ao abrir
        txtUsuario.requestFocus();
    
        // Permitir Enter para fazer login
        txtSenha.addActionListener(new java.awt.event.ActionListener() 
    
    {
        public void actionPerformed(java.awt.event.ActionEvent evt) 
        {
        btnEntrar.doClick(); 
        }
    });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtSenha = new javax.swing.JPasswordField();
        btnEntrar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Faça seu Login");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 20)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LOGIN");

        jLabel2.setFont(new java.awt.Font("Source Han Sans CN Regular", 1, 14)); // NOI18N
        jLabel2.setText("Usuário");

        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Source Han Sans CN Regular", 1, 14)); // NOI18N
        jLabel3.setText("Senha");

        btnEntrar.setBackground(new java.awt.Color(255, 255, 255));
        btnEntrar.setText("Entrar");
        btnEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarActionPerformed(evt);
            }
        });

        btnCancelar.setBackground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addGap(58, 58, 58)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEntrar)
                    .addComponent(btnCancelar))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void btnEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarActionPerformed
     String usuario = txtUsuario.getText().trim();
     String senha = new String(txtSenha.getPassword());
    
    if (usuario.isEmpty() || senha.isEmpty()) 
    {
        JOptionPane.showMessageDialog(this, 
        "Preencha usuário e senha!", 
        "Campos Obrigatórios", 
        JOptionPane.WARNING_MESSAGE);
        if (usuario.isEmpty()) 
        {
            txtUsuario.requestFocus();
        } else
        {
            txtSenha.requestFocus();
        }
        return;
    }
    
    
    if (usuario.length() < 3) 
    {
        JOptionPane.showMessageDialog(this, 
        "Usuário deve ter pelo menos 3 caracteres!", 
        "Erro de Validação", 
        JOptionPane.ERROR_MESSAGE);
        txtUsuario.requestFocus();
        txtUsuario.selectAll();
        return;
    }
    
    if (senha.length() < 3) 
    {
        JOptionPane.showMessageDialog(this, 
        "Senha deve ter pelo menos 3 caracteres!", 
        "Erro de Validação", 
        JOptionPane.ERROR_MESSAGE);
        txtSenha.requestFocus();
        txtSenha.selectAll();
        return;
    }
    
    
    if (usuario.contains("'") || usuario.contains("\"") || usuario.contains(";") || usuario.contains("--")) 
    {
        JOptionPane.showMessageDialog(this, 
        "Usuário contém caracteres inválidos!", 
        "Erro de Validação", 
        JOptionPane.ERROR_MESSAGE);
        txtUsuario.requestFocus();
        limparCampos();
        return;
    }
    
    
    if (tentativasLogin >= 3) 
    {
        JOptionPane.showMessageDialog(this, 
        "Número máximo de tentativas excedido!\nO sistema será bloqueado por segurança.", 
        "Acesso Bloqueado", 
        JOptionPane.ERROR_MESSAGE);
        bloquearSistema();
        return;
    }
    
    
    if (validarLogin(usuario, senha)) 
    {
        JOptionPane.showMessageDialog(this, 
        "Login realizado com sucesso!\nBem-vindo, " + usuario + "!", 
        "Sucesso", 
        JOptionPane.INFORMATION_MESSAGE);
        
        // Resetar contador de tentativas
        tentativasLogin = 0;
        
        // Abrir tela principal
        TelaPrincipal principal = new TelaPrincipal();
        principal.setVisible(true);
        principal.setLocationRelativeTo(null);
        
        // Fechar tela de login
        this.dispose();
        
    } else 
    {
        // Login falhou
        tentativasLogin++;
        int tentativasRestantes = 3 - tentativasLogin;
        
        if (tentativasRestantes > 0) 
        {
            JOptionPane.showMessageDialog(this, 
            "Usuário ou senha incorretos!\n\nTentativas restantes: " + tentativasRestantes, 
            "Erro de Login", 
            JOptionPane.ERROR_MESSAGE);
        }
        else 
        {
            JOptionPane.showMessageDialog(this, 
            "Número máximo de tentativas excedido!\nO sistema será bloqueado.", 
            "Acesso Bloqueado", 
            JOptionPane.ERROR_MESSAGE);
            bloquearSistema();
        }
        
        txtSenha.setText("");
        txtSenha.requestFocus();
    }
    }//GEN-LAST:event_btnEntrarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnCancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) 
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TelaLogin().setVisible(true));
    }
    
    private boolean validarLogin(String usuario, String senha) 
    {
    Connection conexao = ConexaoDB.conectar();
    
    if (conexao == null) 
    {
        JOptionPane.showMessageDialog(this, 
            "Erro ao conectar com o banco de dados!\nVerifique a conexão.", 
            "Erro de Conexão", 
            JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    try 
    {
        // Usar PreparedStatement para prevenir SQL Injection
        String sql = "SELECT id, nome, tipo FROM usuarios WHERE usuario = ? AND senha = ?";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setString(1, usuario);
        stmt.setString(2, senha);
        
        ResultSet rs = stmt.executeQuery();
        boolean loginValido = rs.next();
        
        // Log de tentativa de login (opcional)
        if (loginValido) 
        {
            String nomeUsuario = rs.getString("nome");
            String tipoUsuario = rs.getString("tipo");
            System.out.println("Login bem-sucedido: " + nomeUsuario + " (" + tipoUsuario + ")");
        } 
        else 
        {
            System.out.println("Tentativa de login falhou para usuário: " + usuario);
        }
        
        rs.close();
        stmt.close();
        ConexaoDB.desconectar(conexao);
        
        return loginValido;
        
    } 
    catch (SQLException e) 
    {
        JOptionPane.showMessageDialog(this, 
            "Erro ao validar login: " + e.getMessage(), 
            "Erro de Sistema", 
            JOptionPane.ERROR_MESSAGE);
        return false;
    }
}
     private void bloquearSistema() {
        // Desabilitar campos e botões
        txtUsuario.setEnabled(false);
        txtSenha.setEnabled(false);
        btnEntrar.setEnabled(false);
        
        // Aguardar 30 segundos antes de fechar
        new Thread(() -> {
            try {
                Thread.sleep(30000); // 30 segundos
                System.exit(0);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void limparCampos() {
        txtUsuario.setText("");
        txtSenha.setText("");
        txtUsuario.requestFocus();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEntrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPasswordField txtSenha;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
