package sistemajava.dao;

import sistemajava.modelo.Faculdade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;;

public class FaculdadeDAO 
{
    
    /**
     * Inserir uma nova faculdade no banco
     */
    public boolean inserir(Faculdade faculdade)
    
    {
        Connection conexao = ConexaoDB.conectar();
        
        try {
            String sql = "INSERT INTO faculdades (nome, cnpj, endereco, telefone, email) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, faculdade.getNome());
            stmt.setString(2, faculdade.getCnpj());
            stmt.setString(3, faculdade.getEndereco());
            stmt.setString(4, faculdade.getTelefone());
            stmt.setString(5, faculdade.getEmail());
            
            stmt.executeUpdate();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir faculdade: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Listar todas as faculdades
     */
    public List<Faculdade> listarTodas() 
    
    {
        List<Faculdade> lista = new ArrayList<>();
        Connection conexao = ConexaoDB.conectar();
        
        try {
            String sql = "SELECT * FROM faculdades ORDER BY nome";
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Faculdade f = new Faculdade();
                f.setId(rs.getInt("id"));
                f.setNome(rs.getString("nome"));
                f.setCnpj(rs.getString("cnpj"));
                f.setEndereco(rs.getString("endereco"));
                f.setTelefone(rs.getString("telefone"));
                f.setEmail(rs.getString("email"));
                
                lista.add(f);
            }
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar faculdades: " + e.getMessage());
        }
        
        return lista;
    }
    
    
    public Faculdade buscarPorId(int id) 
    
    {
        Connection conexao = ConexaoDB.conectar();
        Faculdade faculdade = null;
        
        try {
            String sql = "SELECT * FROM faculdades WHERE id = ?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                faculdade = new Faculdade();
                faculdade.setId(rs.getInt("id"));
                faculdade.setNome(rs.getString("nome"));
                faculdade.setCnpj(rs.getString("cnpj"));
                faculdade.setEndereco(rs.getString("endereco"));
                faculdade.setTelefone(rs.getString("telefone"));
                faculdade.setEmail(rs.getString("email"));
            }
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar faculdade: " + e.getMessage());
        }
        
        return faculdade;
    }
    public boolean atualizar(Faculdade faculdade) {
    Connection conexao = ConexaoDB.conectar();
    
    try 
    {
        String sql = "UPDATE faculdades SET nome=?, cnpj=?, endereco=?, telefone=?, email=? WHERE id=?";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        
        stmt.setString(1, faculdade.getNome());
        stmt.setString(2, faculdade.getCnpj());
        stmt.setString(3, faculdade.getEndereco());
        stmt.setString(4, faculdade.getTelefone());
        stmt.setString(5, faculdade.getEmail());
        stmt.setInt(6, faculdade.getId());
        
        stmt.executeUpdate();
        stmt.close();
        ConexaoDB.desconectar(conexao);
        
        return true;
        
    } 
    catch (SQLException e) 
    {
        JOptionPane.showMessageDialog(null, "Erro ao atualizar faculdade: " + e.getMessage());
        return false;
    }
}

/**
 * Excluir faculdade
 */
public boolean excluir(int id) 
{
    Connection conexao = ConexaoDB.conectar();
    
    try 
    {
        String sql = "DELETE FROM faculdades WHERE id=?";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setInt(1, id);
        
        stmt.executeUpdate();
        stmt.close();
        ConexaoDB.desconectar(conexao);
        
        return true;
        
    } 
    catch (SQLException e) 
    {
        JOptionPane.showMessageDialog(null, "Erro ao excluir faculdade: " + e.getMessage());
        return false;
    }
}
    
}