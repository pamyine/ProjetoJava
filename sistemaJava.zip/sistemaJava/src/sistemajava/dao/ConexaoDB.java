package sistemajava.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoDB 
{
    
    
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_escola";
    private static final String USUARIO = "root";
    private static final String SENHA = "PAMSQLa8741!@";  
    
    
    public static Connection conectar() {
        try 
        {
            Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
            System.out.println("✅ Conexão realizada com sucesso!");
            return conexao;
        } catch (SQLException e) {
            System.out.println("❌ Erro ao conectar: " + e.getMessage());
            return null;
        }
    }
    
    
    public static void desconectar(Connection conexao) 
    {
        try {
            if (conexao != null && !conexao.isClosed()) {
                conexao.close();
                System.out.println("✅ Conexão encerrada!");
            }
        } catch (SQLException e) {
            System.out.println("❌ Erro ao desconectar: " + e.getMessage());
        }
    }
    
    
    public static void main(String[] args) 
    {
        Connection conn = conectar();
        if (conn != null) {
            System.out.println("Teste de conexão OK! ✅");
            desconectar(conn);
        } else {
            System.out.println("Falha no teste de conexão! ❌");
        }
    }
}
