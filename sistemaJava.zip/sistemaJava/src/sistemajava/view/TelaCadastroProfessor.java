package sistemajava.view;

import sistemajava.dao.ProfessorDAO;
import sistemajava.dao.FaculdadeDAO;
import sistemajava.modelo.Professor;
import sistemajava.modelo.Faculdade;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import sistemajava.view.TelaPrincipal;

public class TelaCadastroProfessor extends javax.swing.JFrame {

    private ProfessorDAO professorDAO;
    private FaculdadeDAO faculdadeDAO;
    private int idSelecionado = 0;

    public TelaCadastroProfessor() {
        initComponents();
        professorDAO = new ProfessorDAO();
        faculdadeDAO = new FaculdadeDAO();
        carregarComboFaculdades();
        carregarTabela();
        txtCpf.setToolTipText("Digite o CPF com ou sem pontos. Ex: 123.456.789-00");
        txtEmail.setToolTipText("Digite um email válido. Ex: professor@email.com");
        txtDataNascimento.setToolTipText("Digite a data no formato: AAAA-MM-DD. Ex: 2000-05-15");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTitulacao = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtAreaAtuacao = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtDataNascimento = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cbFaculdade = new javax.swing.JComboBox<>();
        btnSalvar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        JscrollPane = new javax.swing.JScrollPane();
        tblProfessores = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro de Professores");
        setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("FAÇA SEU CADASTRO AQUI:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Nome:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("CPF:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("E-mail:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Titulação:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Área de Atuação:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Data de Nascimento:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Telefone:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Faculdade:");

        cbFaculdade.setModel(new javax.swing.DefaultComboBoxModel<>());

        btnSalvar.setBackground(new java.awt.Color(255, 255, 255));
        btnSalvar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnLimpar.setBackground(new java.awt.Color(255, 255, 255));
        btnLimpar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnExcluir.setBackground(new java.awt.Color(255, 255, 255));
        btnExcluir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnVoltar.setBackground(new java.awt.Color(255, 255, 255));
        btnVoltar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        JscrollPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JscrollPaneMouseClicked(evt);
            }
        });

        tblProfessores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "CPF", "Email", "Titulação", "Área Atuação", "Telefone", "Data de Nascimento", "Faculdade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        JscrollPane.setViewportView(tblProfessores);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JscrollPane)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3))
                                    .addGap(12, 12, 12)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtCpf, javax.swing.GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                                        .addComponent(txtNome)))
                                .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtTitulacao, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtAreaAtuacao, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtTelefone)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cbFaculdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtTitulacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtAreaAtuacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(cbFaculdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(84, 84, 84)
                .addComponent(JscrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnLimpar)
                    .addComponent(btnExcluir)
                    .addComponent(btnVoltar))
                .addContainerGap(125, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if (validarCampos()) {
            Professor professor = new Professor();
            professor.setNome(txtNome.getText());
            professor.setCpf(txtCpf.getText());
            professor.setEmail(txtEmail.getText());
            professor.setTitulacao(txtTitulacao.getText());
            professor.setAreaAtuacao(txtAreaAtuacao.getText());
            professor.setDataNascimento(txtDataNascimento.getText());
            professor.setTelefone(txtTelefone.getText());

            // Pegar o ID da faculdade selecionada
            Faculdade facSelecionada = (Faculdade) cbFaculdade.getSelectedItem();
            if (facSelecionada != null) {
                professor.setIdFaculdade(facSelecionada.getId());
            }

            if (idSelecionado == 0) {
                // Inserir novo
                if (professorDAO.inserir(professor)) {
                    JOptionPane.showMessageDialog(this, "Professor cadastrado com sucesso!");
                    limparCampos();
                    carregarTabela();
                }
            } else {
                // Atualizar existente
                professor.setId(idSelecionado);
                if (professorDAO.atualizar(professor)) {
                    JOptionPane.showMessageDialog(this, "Professor atualizado com sucesso!");
                    limparCampos();
                    carregarTabela();
                    idSelecionado = 0;
                }
            }

        }
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (idSelecionado == 0) {
            JOptionPane.showMessageDialog(this, "Selecione um professor na tabela para excluir!");
            return;
        }

        int opcao = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este professor?",
                "Confirmar Exclusão",
                JOptionPane.YES_NO_OPTION);

        if (opcao == JOptionPane.YES_OPTION) {
            if (professorDAO.excluir(idSelecionado)) {
                JOptionPane.showMessageDialog(this, "Professor excluído com sucesso!");
                limparCampos();
                carregarTabela();
                idSelecionado = 0;
            }
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        TelaInicio inicio = new TelaInicio();
        inicio.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void JscrollPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JscrollPaneMouseClicked
        int linha = tblProfessores.getSelectedRow();
        if (linha != -1) {
            idSelecionado = Integer.parseInt(tblProfessores.getValueAt(linha, 0).toString());
            txtNome.setText(tblProfessores.getValueAt(linha, 1).toString());
            txtCpf.setText(tblProfessores.getValueAt(linha, 2).toString());
            txtEmail.setText(tblProfessores.getValueAt(linha, 3).toString());
            txtTitulacao.setText(tblProfessores.getValueAt(linha, 4).toString());
            txtAreaAtuacao.setText(tblProfessores.getValueAt(linha, 5).toString());
            txtTelefone.setText(tblProfessores.getValueAt(linha, 6).toString());
            txtDataNascimento.setText(tblProfessores.getValueAt(linha, 7).toString());

            // Selecionar a faculdade no combo
            Object valorFaculdade = tblProfessores.getValueAt(linha, 8);
            if (valorFaculdade != null && !valorFaculdade.toString().isEmpty()) {
                String nomeFaculdade = valorFaculdade.toString();
                // Procurar a faculdade no combo pelo nome
                for (int i = 0; i < cbFaculdade.getItemCount(); i++) {
                    Object item = cbFaculdade.getItemAt(i);
                    if (item instanceof Faculdade) {
                        Faculdade f = (Faculdade) item;
                        if (f.getNome().equals(nomeFaculdade)) {
                            cbFaculdade.setSelectedIndex(i);
                            break;
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_JscrollPaneMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroProfessor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroProfessor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroProfessor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroProfessor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroProfessor().setVisible(true);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void carregarComboFaculdades() {
    cbFaculdade.removeAllItems();
    List<Faculdade> lista = faculdadeDAO.listarTodas();
    for (Faculdade f : lista) {
        ((javax.swing.JComboBox) cbFaculdade).addItem(f);
    }
}

    private void carregarTabela() {
        DefaultTableModel modelo = (DefaultTableModel) tblProfessores.getModel();
        modelo.setRowCount(0);

        List<Professor> lista = professorDAO.listarTodos();

        for (Professor p : lista) {
            modelo.addRow(new Object[]{
                p.getId(), // Coluna 0
                p.getNome(), // Coluna 1
                p.getCpf(), // Coluna 2
                p.getEmail(), // Coluna 3
                p.getTitulacao(), // Coluna 4
                p.getAreaAtuacao(), // Coluna 5
                p.getTelefone(), // Coluna 6
                p.getDataNascimento(), // Coluna 7
                p.getNomeFaculdade() // Coluna 8
            });
        }
    }

    private void limparCampos() {
        txtNome.setText("");
        txtCpf.setText("");
        txtEmail.setText("");
        txtTitulacao.setText("");
        txtAreaAtuacao.setText("");
        txtDataNascimento.setText("");
        txtTelefone.setText("");
        cbFaculdade.setSelectedIndex(-1);
        idSelecionado = 0;
        tblProfessores.clearSelection();
    }

    private boolean validarCampos() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha o nome do professor!");
            txtNome.requestFocus();
            return false;
        }

        if (txtCpf.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha o CPF!");
            txtCpf.requestFocus();
            return false;
        }

        String cpf = txtCpf.getText().replaceAll("[^0-9]", ""); // Remove pontos e traços
        if (cpf.length() != 11) {
            JOptionPane.showMessageDialog(this,
                    "CPF inválido! Deve conter 11 dígitos.\nExemplo: 123.456.789-00 ou 12345678900",
                    "Erro de Validação",
                    JOptionPane.ERROR_MESSAGE);
            txtCpf.requestFocus();
            txtCpf.selectAll();
            return false;
        }

        if (txtEmail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha o email!");
            txtEmail.requestFocus();
            return false;
        }

        String email = txtEmail.getText().trim();
        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(this,
                    "Email inválido! Deve conter @ e um domínio.\nExemplo: professor@email.com",
                    "Erro de Validação",
                    JOptionPane.ERROR_MESSAGE);
            txtEmail.requestFocus();
            txtEmail.selectAll();
            return false;
        }

        if (txtDataNascimento.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha a data de nascimento!");
            txtDataNascimento.requestFocus();
            return false;
        }

        String data = txtDataNascimento.getText().trim();
        if (!data.matches("\\d{4}-\\d{2}-\\d{2}")) {
            JOptionPane.showMessageDialog(this,
                    "Data inválida! Use o formato: AAAA-MM-DD\nExemplo: 2000-05-15",
                    "Erro de Validação",
                    JOptionPane.ERROR_MESSAGE);
            txtDataNascimento.requestFocus();
            txtDataNascimento.selectAll();
            return false;
        }

        try {
            String[] partes = data.split("-");
            int ano = Integer.parseInt(partes[0]);
            int mes = Integer.parseInt(partes[1]);
            int dia = Integer.parseInt(partes[2]);

            if (mes < 1 || mes > 12) {
                JOptionPane.showMessageDialog(this,
                        "Mês inválido! Deve estar entre 01 e 12.",
                        "Erro de Validação",
                        JOptionPane.ERROR_MESSAGE);
                txtDataNascimento.requestFocus();
                return false;
            }

            if (dia < 1 || dia > 31) {
                JOptionPane.showMessageDialog(this,
                        "Dia inválido! Deve estar entre 01 e 31.",
                        "Erro de Validação",
                        JOptionPane.ERROR_MESSAGE);
                txtDataNascimento.requestFocus();
                return false;
            }

            int anoAtual = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
            if (ano < 1930 || ano > anoAtual) {
                JOptionPane.showMessageDialog(this,
                        "Ano inválido! Deve estar entre 1930 e " + anoAtual + ".",
                        "Erro de Validação",
                        JOptionPane.ERROR_MESSAGE);
                txtDataNascimento.requestFocus();
                return false;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Data inválida! Use o formato: AAAA-MM-DD\nExemplo: 2000-05-15",
                    "Erro de Validação",
                    JOptionPane.ERROR_MESSAGE);
            txtDataNascimento.requestFocus();
            return false;
        }

        if (cbFaculdade.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma faculdade!");
            cbFaculdade.requestFocus();
            return false;
        }

        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane JscrollPane;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JComboBox<String> cbFaculdade;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTable tblProfessores;
    private javax.swing.JTextField txtAreaAtuacao;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtDataNascimento;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTelefone;
    private javax.swing.JTextField txtTitulacao;
    // End of variables declaration//GEN-END:variables
}
