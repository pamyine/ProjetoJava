package sistemajava.dao;

import sistemajava.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class UsuarioDAO 
{
    
    public boolean inserir(Usuario usuario) 
    {
        Connection conexao = ConexaoDB.conectar();
        
        try 
        {
            String sql = "INSERT INTO usuarios (usuario, senha, nome, tipo) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, usuario.getUsuario());
            stmt.setString(2, usuario.getSenha());
            stmt.setString(3, usuario.getNome());
            stmt.setString(4, usuario.getTipo());
            
            stmt.executeUpdate();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return true;
            
        } 
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao inserir usuario: " + e.getMessage());
            return false;
        }
    }
    
    public List<Usuario> listarTodos() 
    {
        List<Usuario> lista = new ArrayList<Usuario>();
        Connection conexao = ConexaoDB.conectar();
        
        try 
        {
            String sql = "SELECT * FROM usuarios ORDER BY nome";
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) 
            {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setUsuario(rs.getString("usuario"));
                u.setSenha(rs.getString("senha"));
                u.setNome(rs.getString("nome"));
                u.setTipo(rs.getString("tipo"));
                
                lista.add(u);
            }
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
        } 
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao listar usuarios: " + e.getMessage());
        }
        
        return lista;
    }
    
    public boolean atualizar(Usuario usuario) {
        Connection conexao = ConexaoDB.conectar();
        
        try {
            String sql = "UPDATE usuarios SET usuario=?, senha=?, nome=?, tipo=? WHERE id=?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, usuario.getUsuario());
            stmt.setString(2, usuario.getSenha());
            stmt.setString(3, usuario.getNome());
            stmt.setString(4, usuario.getTipo());
            stmt.setInt(5, usuario.getId());
            
            stmt.executeUpdate();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar usuario: " + e.getMessage());
            return false;
        }
    }
    
    public boolean excluir(int id) 
    {
        Connection conexao = ConexaoDB.conectar();
        
        try 
        {
            String sql = "DELETE FROM usuarios WHERE id=?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setInt(1, id);
            
            stmt.executeUpdate();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return true;
            
        } catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao excluir usuario: " + e.getMessage());
            return false;
        }
    }
    
    public boolean usuarioExiste(String usuario) 
    {
        Connection conexao = ConexaoDB.conectar();
        
        try 
        {
            String sql = "SELECT COUNT(*) FROM usuarios WHERE usuario = ?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, usuario);
            
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return count > 0;
            
        } 
        catch (SQLException e)
        {
            return false;
        }
    }
    
    public Usuario validarLogin(String usuario, String senha) 
    {
        Connection conexao = ConexaoDB.conectar();
        Usuario u = null;
        
        try 
        {
            String sql = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) 
            {
                u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setUsuario(rs.getString("usuario"));
                u.setSenha(rs.getString("senha"));
                u.setNome(rs.getString("nome"));
                u.setTipo(rs.getString("tipo"));
            }
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
        } 
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao validar login: " + e.getMessage());
        }
        
        return u;
    }
}