package sistemajava.dao;

import sistemajava.modelo.Aluno;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class AlunoDAO 
{
    
    
    public boolean inserir(Aluno aluno) 
    {
        Connection conexao = ConexaoDB.conectar();
        
        try 
        {
            String sql = "INSERT INTO alunos (nome, cpf, email, curso, data_nascimento, telefone, id_faculdade) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setString(3, aluno.getEmail());
            stmt.setString(4, aluno.getCurso());
            stmt.setString(5, aluno.getDataNascimento());
            stmt.setString(6, aluno.getTelefone());
            stmt.setInt(7, aluno.getIdFaculdade());
            
            stmt.executeUpdate();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return true;
            
        } catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao inserir aluno: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Listar todos os alunos com o nome da faculdade
     */
    public List<Aluno> listarTodos() 
    {
        List<Aluno> lista = new ArrayList<>();
        Connection conexao = ConexaoDB.conectar();
        
        try 
        {
            String sql = "SELECT a.*, f.nome as nome_faculdade " +
                        "FROM alunos a " +
                        "LEFT JOIN faculdades f ON a.id_faculdade = f.id " +
                        "ORDER BY a.nome";
            
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) 
            {
                Aluno a = new Aluno();
                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setCpf(rs.getString("cpf"));
                a.setEmail(rs.getString("email"));
                a.setCurso(rs.getString("curso"));
                a.setDataNascimento(rs.getString("data_nascimento"));
                a.setTelefone(rs.getString("telefone"));
                a.setIdFaculdade(rs.getInt("id_faculdade"));
                a.setNomeFaculdade(rs.getString("nome_faculdade"));
                
                lista.add(a);
            }
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
        } catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao listar alunos: " + e.getMessage());
        }
        
        return lista;
    }
}