package sistemajava.view;

import sistemajava.dao.AlunoDAO;
import sistemajava.dao.FaculdadeDAO;
import sistemajava.modelo.Aluno;
import sistemajava.modelo.Faculdade;
import sistemajava.view.TelaInicio;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sistemajava.view.TelaPrincipal;

public class TelaCadastroAluno extends JFrame 
{    
    // Componentes
    private JTextField txtNome;
    private JTextField txtCpf;
    private JTextField txtEmail;
    private JTextField txtCurso;
    private JTextField txtDataNascimento;
    private JTextField txtTelefone;
    private JComboBox<Faculdade> cbFaculdade;
    private JButton btnSalvar;
    private JButton btnLimpar;
    private JButton btnExcluir;
    private JButton btnVoltar;
    private JTable tblAlunos;
    private JScrollPane scrollPane;
    
    // DAO e controle
    private AlunoDAO alunoDAO;
    private FaculdadeDAO faculdadeDAO;
    private int idSelecionado = 0;
    
    // Construtor
    public TelaCadastroAluno() 
    {
        alunoDAO = new AlunoDAO();
        faculdadeDAO = new FaculdadeDAO();
        initComponents();
        carregarComboFaculdades();
        carregarTabela();
    }
    
    // Criar e configurar componentes
    private void initComponents() 
    {
        setTitle("Cadastro de Alunos");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        JLabel lblTitulo = new JLabel("CADASTRO DE ALUNOS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setBounds(330, 20, 300, 30);
        add(lblTitulo);
        
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(30, 70, 100, 25);
        add(lblNome);
        txtNome = new JTextField();
        txtNome.setBounds(140, 70, 300, 25);
        add(txtNome);
        
        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setBounds(30, 105, 100, 25);
        add(lblCpf);
        txtCpf = new JTextField();
        txtCpf.setBounds(140, 105, 200, 25);
        txtCpf.setToolTipText("Ex: 123.456.789-00");
        add(txtCpf);
        
        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(30, 140, 100, 25);
        add(lblEmail);
        txtEmail = new JTextField();
        txtEmail.setBounds(140, 140, 300, 25);
        txtEmail.setToolTipText("Ex: aluno@email.com");
        add(txtEmail);
        
        JLabel lblCurso = new JLabel("Curso:");
        lblCurso.setBounds(30, 175, 100, 25);
        add(lblCurso);
        txtCurso = new JTextField();
        txtCurso.setBounds(140, 175, 300, 25);
        add(txtCurso);
        
        JLabel lblDataNasc = new JLabel("Data Nascimento:");
        lblDataNasc.setBounds(480, 70, 120, 25);
        add(lblDataNasc);
        txtDataNascimento = new JTextField();
        txtDataNascimento.setBounds(600, 70, 150, 25);
        txtDataNascimento.setToolTipText("Ex: 2000-05-15");
        add(txtDataNascimento);
        
        JLabel lblTelefone = new JLabel("Telefone:");
        lblTelefone.setBounds(480, 105, 100, 25);
        add(lblTelefone);
        txtTelefone = new JTextField();
        txtTelefone.setBounds(600, 105, 150, 25);
        add(txtTelefone);
        
        JLabel lblFaculdade = new JLabel("Faculdade:");
        lblFaculdade.setBounds(30, 210, 100, 25);
        add(lblFaculdade);
        cbFaculdade = new JComboBox<Faculdade>();
        cbFaculdade.setBounds(140, 210, 300, 25);
        add(cbFaculdade);
        
        btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(30, 260, 100, 30);
        btnSalvar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnSalvarActionPerformed();
            }
        });
        add(btnSalvar);
        
        btnLimpar = new JButton("Limpar");
        btnLimpar.setBounds(140, 260, 100, 30);
        btnLimpar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                limparCampos();
            }
        });
        add(btnLimpar);
        
        btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(250, 260, 100, 30);
        btnExcluir.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnExcluirActionPerformed();
            }
        });
        add(btnExcluir);
        
        btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(360, 260, 100, 30);
        btnVoltar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnVoltarActionPerformed();
            }
        });
        add(btnVoltar);
        
        String[] colunas = {"ID", "Nome", "CPF", "Email", "Curso", "Telefone", "Data Nasc", "Faculdade"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        tblAlunos = new JTable(modelo);
        tblAlunos.addMouseListener(new MouseAdapter() 
        {
            public void mouseClicked(MouseEvent e) 
            {
                tblAlunosMouseClicked();
            }
        });
        
        scrollPane = new JScrollPane(tblAlunos);
        scrollPane.setBounds(30, 310, 830, 280);
        add(scrollPane);
    }
    
    private void carregarComboFaculdades() 
    {
        cbFaculdade.removeAllItems();
        List<Faculdade> lista = faculdadeDAO.listarTodas();
        for (Faculdade f : lista) 
        {
            cbFaculdade.addItem(f);
        }
    }
    
    private void btnSalvarActionPerformed()
    {
        if (validarCampos()) 
        {
            Aluno aluno = new Aluno();
            aluno.setNome(txtNome.getText().trim());
            aluno.setCpf(txtCpf.getText().trim());
            aluno.setEmail(txtEmail.getText().trim());
            aluno.setCurso(txtCurso.getText().trim());
            aluno.setDataNascimento(txtDataNascimento.getText().trim());
            aluno.setTelefone(txtTelefone.getText().trim());
            
            Faculdade facSelecionada = (Faculdade) cbFaculdade.getSelectedItem();
            if (facSelecionada != null) 
            {
                aluno.setIdFaculdade(facSelecionada.getId());
            }
            
            if (idSelecionado == 0) 
            {
                if (alunoDAO.inserir(aluno)) 
                {
                    JOptionPane.showMessageDialog(this, "Aluno cadastrado com sucesso!");
                    limparCampos();
                    carregarTabela();
                }
            } 
            else 
            {
                aluno.setId(idSelecionado);
                if (alunoDAO.atualizar(aluno)) 
                {
                    JOptionPane.showMessageDialog(this, "Aluno atualizado com sucesso!");
                    limparCampos();
                    carregarTabela();
                    idSelecionado = 0;
                }
            }
        }
    }
    
    private void btnExcluirActionPerformed() 
    {
        if (idSelecionado == 0) 
        {
            JOptionPane.showMessageDialog(this, "Selecione um aluno na tabela para excluir!");
            return;
        }
        
        int opcao = JOptionPane.showConfirmDialog(this, 
            "Deseja realmente excluir este aluno?", 
            "Confirmar Exclusao", 
            JOptionPane.YES_NO_OPTION);
        
        if (opcao == JOptionPane.YES_OPTION) 
        {
            if (alunoDAO.excluir(idSelecionado)) 
            {
                JOptionPane.showMessageDialog(this, "Aluno excluido com sucesso!");
                limparCampos();
                carregarTabela();
                idSelecionado = 0;
            }
        }
    }
    
    private void btnVoltarActionPerformed() 
    {
        TelaPrincipal principal = new TelaPrincipal();
        principal.setVisible(true);
        this.dispose();
    }
    
    private void tblAlunosMouseClicked() 
    {
        int linha = tblAlunos.getSelectedRow();
        if (linha != -1) 
        {
            idSelecionado = Integer.parseInt(tblAlunos.getValueAt(linha, 0).toString());
            txtNome.setText(tblAlunos.getValueAt(linha, 1).toString());
            txtCpf.setText(tblAlunos.getValueAt(linha, 2).toString());
            txtEmail.setText(tblAlunos.getValueAt(linha, 3).toString());
            txtCurso.setText(tblAlunos.getValueAt(linha, 4).toString());
            txtTelefone.setText(tblAlunos.getValueAt(linha, 5).toString());
            txtDataNascimento.setText(tblAlunos.getValueAt(linha, 6).toString());
            
            String nomeFaculdade = tblAlunos.getValueAt(linha, 7).toString();
            for (int i = 0; i < cbFaculdade.getItemCount(); i++) 
            {
                Faculdade f = cbFaculdade.getItemAt(i);
                if (f != null && f.getNome().equals(nomeFaculdade)) 
                {
                    cbFaculdade.setSelectedIndex(i);
                    break;
                }
            }
        }
    }
    
    private void carregarTabela() 
    {
        DefaultTableModel modelo = (DefaultTableModel) tblAlunos.getModel();
        modelo.setRowCount(0);
        
        List<Aluno> lista = alunoDAO.listarTodos();
        
        for (Aluno a : lista) 
        {
            modelo.addRow(new Object[]{
                a.getId(),
                a.getNome(),
                a.getCpf(),
                a.getEmail(),
                a.getCurso(),
                a.getTelefone(),
                a.getDataNascimento(),
                a.getNomeFaculdade()
            });
        }
    }
    
    private void limparCampos() 
    {
        txtNome.setText("");
        txtCpf.setText("");
        txtEmail.setText("");
        txtCurso.setText("");
        txtDataNascimento.setText("");
        txtTelefone.setText("");
        cbFaculdade.setSelectedIndex(-1);
        idSelecionado = 0;
        tblAlunos.clearSelection();
    }
    
    private boolean validarCampos() 
    {
        if (txtNome.getText().trim().isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Preencha o nome do aluno!");
            txtNome.requestFocus();
            return false;
        }
        if (txtCpf.getText().trim().isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Preencha o CPF!");
            txtCpf.requestFocus();
            return false;
        }
        if (cbFaculdade.getSelectedIndex() == -1) 
        {
            JOptionPane.showMessageDialog(this, "Selecione uma faculdade!");
            cbFaculdade.requestFocus();
            return false;
        }
        return true;
    }
    
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new TelaCadastroAluno().setVisible(true);
            }
        });
    }
}