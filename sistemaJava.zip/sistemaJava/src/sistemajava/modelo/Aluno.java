package sistemajava.modelo;

public class Aluno 
{
    private int id;
    private String nome;
    private String cpf;
    private String email;
    private String curso;
    private String dataNascimento;
    private String telefone;
    private int idFaculdade;
    private String nomeFaculdade; // Para exibir na consulta
    
    
    public Aluno() {
    }
    
    
    public Aluno(String nome, String cpf, String email, String curso, 
                String dataNascimento, String telefone, int idFaculdade) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.curso = curso;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
        this.idFaculdade = idFaculdade;
    }
    
    
    public int getId() 
    {
        return id;
    }
    
    public void setId(int id) 
    {
        this.id = id;
    }
    
    public String getNome() 
    {
        return nome;
    }
    
    public void setNome(String nome) 
    {
        this.nome = nome;
    }
    
    public String getCpf() 
    {
        return cpf;
    }
    
    public void setCpf(String cpf) 
    {
        this.cpf = cpf;
    }
    
    public String getEmail() 
    {
        return email;
    }
    
    public void setEmail(String email) 
    {
        this.email = email;
    }
    
    public String getCurso() 
    {
        return curso;
    }
    
    public void setCurso(String curso) 
    {
        this.curso = curso;
    }
    
    public String getDataNascimento() 
    {
        return dataNascimento;
    }
    
    public void setDataNascimento(String dataNascimento) 
    {
        this.dataNascimento = dataNascimento;
    }
    
    public String getTelefone() 
    {
        return telefone;
    }
    
    public void setTelefone(String telefone) 
    {
        this.telefone = telefone;
    }
    
    public int getIdFaculdade() 
    {
        return idFaculdade;
    }
    
    public void setIdFaculdade(int idFaculdade) 
    {
        this.idFaculdade = idFaculdade;
    }
    
    public String getNomeFaculdade() 
    {
        return nomeFaculdade;
    }
    
    public void setNomeFaculdade(String nomeFaculdade) 
    {
        this.nomeFaculdade = nomeFaculdade;
    }
}

