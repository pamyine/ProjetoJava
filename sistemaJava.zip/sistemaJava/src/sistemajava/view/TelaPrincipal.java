package sistemajava.view;

import sistemajava.view.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TelaPrincipal extends JFrame 
{
    private JLabel lblImagem;
    private JLabel lblBoasVindas;
    private JButton btnCadastroFaculdade;
    private JButton btnCadastroAluno;
    private JButton btnCadastroProfessor;
    private JButton btnConsultaGeral;
    private JButton btnSair;
    
    // Construtor
    public TelaPrincipal() 
    {
        initComponents();
    }
    
    // Criar e configurar componentes
    private void initComponents() 
    {
        setTitle("Menu Principal");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(240, 240, 240));
        
        try 
        {
            ImageIcon iconOriginal = new ImageIcon(getClass().getResource("C:\\Users\\HOME\\Documents\\NetBeansProjects\\sistemaJava\\imagens"));
            Image imagemRedimensionada = iconOriginal.getImage().getScaledInstance(300, 150, Image.SCALE_SMOOTH);
            ImageIcon iconRedimensionado = new ImageIcon(imagemRedimensionada);
            
            lblImagem = new JLabel(iconRedimensionado);
            lblImagem.setBounds(150, 20, 300, 150);
            lblImagem.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 100), 2));
            add(lblImagem);
        } catch (Exception e) 
        {
            lblImagem = new JLabel("SISCAD - SISTEMA ACADEMICO");
            lblImagem.setFont(new Font("Arial", Font.BOLD, 16));
            lblImagem.setHorizontalAlignment(SwingConstants.CENTER);
            lblImagem.setBounds(150, 20, 300, 150);
            lblImagem.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
            add(lblImagem);
        }
        
        // Label Boas Vindas
        lblBoasVindas = new JLabel("BOAS VINDAS AO SISTEMA!", SwingConstants.CENTER);
        lblBoasVindas.setFont(new Font("Arial", Font.BOLD, 18));
        lblBoasVindas.setForeground(new Color(60, 60, 60));
        lblBoasVindas.setBounds(100, 190, 400, 30);
        add(lblBoasVindas);
        
        // Botão Cadastro de Faculdade
        btnCadastroFaculdade = new JButton("Cadastro de Faculdade");
        btnCadastroFaculdade.setBounds(120, 240, 180, 40);
        btnCadastroFaculdade.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCadastroFaculdade.setBackground(new Color(70, 130, 180));
        btnCadastroFaculdade.setForeground(Color.WHITE);
        btnCadastroFaculdade.setFocusPainted(false);
        btnCadastroFaculdade.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCadastroFaculdade.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                abrirCadastroFaculdade();
            }
        });
        add(btnCadastroFaculdade);
        
        // Botão Cadastro de Aluno
        btnCadastroAluno = new JButton("Cadastro de Aluno");
        btnCadastroAluno.setBounds(320, 240, 180, 40);
        btnCadastroAluno.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCadastroAluno.setBackground(new Color(70, 130, 180));
        btnCadastroAluno.setForeground(Color.WHITE);
        btnCadastroAluno.setFocusPainted(false);
        btnCadastroAluno.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCadastroAluno.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                abrirCadastroAluno();
            }
        });
        add(btnCadastroAluno);
        
        // Botão Cadastro de Professor
        btnCadastroProfessor = new JButton("Cadastro de Professor");
        btnCadastroProfessor.setBounds(120, 300, 180, 40);
        btnCadastroProfessor.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCadastroProfessor.setBackground(new Color(70, 130, 180));
        btnCadastroProfessor.setForeground(Color.WHITE);
        btnCadastroProfessor.setFocusPainted(false);
        btnCadastroProfessor.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCadastroProfessor.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                abrirCadastroProfessor();
            }
        });
        add(btnCadastroProfessor);
        
        // Botão Consulta Geral
        btnConsultaGeral = new JButton("Consulta Geral");
        btnConsultaGeral.setBounds(320, 300, 180, 40);
        btnConsultaGeral.setFont(new Font("Arial", Font.PLAIN, 14));
        btnConsultaGeral.setBackground(new Color(34, 139, 34));
        btnConsultaGeral.setForeground(Color.WHITE);
        btnConsultaGeral.setFocusPainted(false);
        btnConsultaGeral.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnConsultaGeral.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                abrirConsultaGeral();
            }
        });
        add(btnConsultaGeral);
        
        // Botão Sair
        btnSair = new JButton("Sair");
        btnSair.setBounds(250, 380, 100, 35);
        btnSair.setFont(new Font("Arial", Font.BOLD, 14));
        btnSair.setBackground(new Color(220, 20, 60));
        btnSair.setForeground(Color.WHITE);
        btnSair.setFocusPainted(false);
        btnSair.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSair.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnSairActionPerformed();
            }
        });
        add(btnSair);
    }
    
    // Métodos para abrir as telas
    private void abrirCadastroFaculdade() 
    {
        TelaCadastroFaculdade tela = new TelaCadastroFaculdade();
        tela.setVisible(true);
        this.dispose();
    }
    
    private void abrirCadastroAluno() 
    {
        TelaCadastroAluno tela = new TelaCadastroAluno();
        tela.setVisible(true);
        this.dispose();
    }
    
    private void abrirCadastroProfessor() 
    {
        TelaCadastroProfessor tela = new TelaCadastroProfessor();
        tela.setVisible(true);
        this.dispose();
    }
    
    private void abrirConsultaGeral() 
    {
        TelaConsultaGeral tela = new TelaConsultaGeral();
        tela.setVisible(true);
        this.dispose();
    }
    
    private void btnSairActionPerformed() 
    {
        int opcao = JOptionPane.showConfirmDialog(this, 
            "Deseja realmente sair do sistema?", 
            "Confirmar Saida", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (opcao == JOptionPane.YES_OPTION) 
        {
            System.exit(0);
        }
    }
    
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new TelaPrincipal().setVisible(true);
            }
        });
    }
}