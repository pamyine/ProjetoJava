package sistemajava.modelo;

public class Professor 
{
    private int id;
    private String nome;
    private String cpf;
    private String email;
    private String titulacao;
    private String areaAtuacao;
    private String dataNascimento;
    private String telefone;
    private int idFaculdade;
    private String nomeFaculdade; 
    
    
    public Professor() {
    }
    
    
    public Professor(String nome, String cpf, String email, String titulacao, 
                    String areaAtuacao, String dataNascimento, String telefone, int idFaculdade) 
    {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.titulacao = titulacao;
        this.areaAtuacao = areaAtuacao;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
        this.idFaculdade = idFaculdade;
    }
    
    
    public int getId() 
    {
        return id;
    }
    
    public void setId(int id) 
    {
        this.id = id;
    }
    
    public String getNome() 
    {
        return nome;
    }
    
    public void setNome(String nome) 
    {
        this.nome = nome;
    }
    
    public String getCpf() 
    {
        return cpf;
    }
    
    public void setCpf(String cpf) 
    {
        this.cpf = cpf;
    }
    
    public String getEmail() 
    {
        return email;
    }
    
    public void setEmail(String email) 
    {
        this.email = email;
    }
    
    public String getTitulacao() 
    {
        return titulacao;
    }
    
    public void setTitulacao(String titulacao) 
    {
        this.titulacao = titulacao;
    }
    
    public String getAreaAtuacao() 
    {
        return areaAtuacao;
    }
    
    public void setAreaAtuacao(String areaAtuacao) 
    {
        this.areaAtuacao = areaAtuacao;
    }
    
    public String getDataNascimento() 
    {
        return dataNascimento;
    }
    
    public void setDataNascimento(String dataNascimento) 
    {
        this.dataNascimento = dataNascimento;
    }
    
    public String getTelefone() 
    {
        return telefone;
    }
    
    public void setTelefone(String telefone) 
    {
        this.telefone = telefone;
    }
    
    public int getIdFaculdade() 
    {
        return idFaculdade;
    }
    
    public void setIdFaculdade(int idFaculdade) 
    {
        this.idFaculdade = idFaculdade;
    }
    
    public String getNomeFaculdade() 
    {
        return nomeFaculdade;
    }
    
    public void setNomeFaculdade(String nomeFaculdade) 
    {
        this.nomeFaculdade = nomeFaculdade;
    }
}