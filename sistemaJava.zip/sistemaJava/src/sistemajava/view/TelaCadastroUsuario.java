package sistemajava.view;

import sistemajava.dao.UsuarioDAO;
import sistemajava.modelo.Usuario;
import sistemajava.view.TelaInicio;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sistemajava.view.TelaPrincipal;

public class TelaCadastroUsuario extends JFrame 
{
    private JTextField txtNome;
    private JTextField txtUsuario;
    private JPasswordField txtSenha;
    private JComboBox<String> cbTipo;
    private JButton btnSalvar;
    private JButton btnLimpar;
    private JButton btnExcluir;
    private JButton btnVoltar;
    private JTable tblUsuarios;
    private JScrollPane scrollPane;
    
    
    private UsuarioDAO usuarioDAO;
    private int idSelecionado = 0;
    
    
    public TelaCadastroUsuario() 
    {
        usuarioDAO = new UsuarioDAO();
        initComponents();
        carregarTabela();
    }
    
    
    private void initComponents()
    {
        setTitle("Cadastro de Usuarios");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        JLabel lblTitulo = new JLabel("CADASTRO DE USUARIOS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setBounds(280, 20, 300, 30);
        add(lblTitulo);
        
        JLabel lblNome = new JLabel("Nome Completo:");
        lblNome.setBounds(30, 70, 120, 25);
        add(lblNome);
        
        txtNome = new JTextField();
        txtNome.setBounds(150, 70, 300, 25);
        add(txtNome);
        
        JLabel lblUsuario = new JLabel("Usuario (Login):");
        lblUsuario.setBounds(30, 105, 120, 25);
        add(lblUsuario);
        
        txtUsuario = new JTextField();
        txtUsuario.setBounds(150, 105, 300, 25);
        add(txtUsuario);
        
        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(30, 140, 120, 25);
        add(lblSenha);
        
        txtSenha = new JPasswordField();
        txtSenha.setBounds(150, 140, 300, 25);
        add(txtSenha);
        
        JLabel lblTipo = new JLabel("Tipo:");
        lblTipo.setBounds(30, 175, 120, 25);
        add(lblTipo);
        
        cbTipo = new JComboBox<String>(new String[]{"admin", "usuario"});
        cbTipo.setBounds(150, 175, 150, 25);
        add(cbTipo);
        
        btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(30, 220, 100, 30);
        btnSalvar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnSalvarActionPerformed();
            }
        });
        add(btnSalvar);
        
        btnLimpar = new JButton("Limpar");
        btnLimpar.setBounds(140, 220, 100, 30);
        btnLimpar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                limparCampos();
            }
        });
        add(btnLimpar);
        
        btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(250, 220, 100, 30);
        btnExcluir.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnExcluirActionPerformed();
            }
        });
        add(btnExcluir);
        
        btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(360, 220, 100, 30);
        btnVoltar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnVoltarActionPerformed();
            }
        });
        add(btnVoltar);
        
        // Tabela
        String[] colunas = {"ID", "Nome", "Usuario", "Tipo"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        tblUsuarios = new JTable(modelo);
        tblUsuarios.addMouseListener(new MouseAdapter() 
        {
            public void mouseClicked(MouseEvent e) 
            {
                tblUsuariosMouseClicked();
            }
        });
        
        scrollPane = new JScrollPane(tblUsuarios);
        scrollPane.setBounds(30, 270, 730, 250);
        add(scrollPane);
    }
    
    private void btnSalvarActionPerformed() 
    {
        if (validarCampos()) {
            Usuario usuario = new Usuario();
            usuario.setNome(txtNome.getText().trim());
            usuario.setUsuario(txtUsuario.getText().trim());
            usuario.setSenha(new String(txtSenha.getPassword()));
            usuario.setTipo((String) cbTipo.getSelectedItem());
            
            if (idSelecionado == 0) {
                if (usuarioDAO.usuarioExiste(usuario.getUsuario())) 
                {
                    JOptionPane.showMessageDialog(this, "Nome de usuario ja existe! Escolha outro.");
                    txtUsuario.requestFocus();
                    return;
                }
                
                if (usuarioDAO.inserir(usuario)) 
                {
                    JOptionPane.showMessageDialog(this, "Usuario cadastrado com sucesso!");
                    limparCampos();
                    carregarTabela();
                }
            } else {
                usuario.setId(idSelecionado);
                if (usuarioDAO.atualizar(usuario)) 
                {
                    JOptionPane.showMessageDialog(this, "Usuario atualizado com sucesso!");
                    limparCampos();
                    carregarTabela();
                    idSelecionado = 0;
                }
            }
        }
    }
    
    // Ação do botão Excluir
    private void btnExcluirActionPerformed() 
    {
        if (idSelecionado == 0) 
        {
            JOptionPane.showMessageDialog(this, "Selecione um usuario na tabela para excluir!");
            return;
        }
        
        int opcao = JOptionPane.showConfirmDialog(this, 
            "Deseja realmente excluir este usuario?", 
            "Confirmar Exclusao", 
            JOptionPane.YES_NO_OPTION);
        
        if (opcao == JOptionPane.YES_OPTION) 
        {
            if (usuarioDAO.excluir(idSelecionado)) 
            {
                JOptionPane.showMessageDialog(this, "Usuario excluido com sucesso!");
                limparCampos();
                carregarTabela();
                idSelecionado = 0;
            }
        }
    }
    
    // Ação do botão Voltar
    private void btnVoltarActionPerformed() 
    {
        TelaPrincipal principal = new TelaPrincipal();
        principal.setVisible(true);
        this.dispose();
    }
    
    // Evento de clique na tabela
    private void tblUsuariosMouseClicked() 
    {
        int linha = tblUsuarios.getSelectedRow();
        if (linha != -1) {
            idSelecionado = Integer.parseInt(tblUsuarios.getValueAt(linha, 0).toString());
            txtNome.setText(tblUsuarios.getValueAt(linha, 1).toString());
            txtUsuario.setText(tblUsuarios.getValueAt(linha, 2).toString());
            txtSenha.setText("");
            cbTipo.setSelectedItem(tblUsuarios.getValueAt(linha, 3).toString());
        }
    }
    
    // Carregar dados na tabela
    private void carregarTabela() 
    {
        DefaultTableModel modelo = (DefaultTableModel) tblUsuarios.getModel();
        modelo.setRowCount(0);
        
        List<Usuario> lista = usuarioDAO.listarTodos();
        
        for (Usuario u : lista) 
        {
            modelo.addRow(new Object[]
            {
                u.getId(),
                u.getNome(),
                u.getUsuario(),
                u.getTipo()
            });
        }
    }
    
    // Limpar campos
    private void limparCampos() 
    {
        txtNome.setText("");
        txtUsuario.setText("");
        txtSenha.setText("");
        cbTipo.setSelectedIndex(0);
        idSelecionado = 0;
        tblUsuarios.clearSelection();
    }
    
    // Validar campos
    private boolean validarCampos() 
    {
        if (txtNome.getText().trim().isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Preencha o nome completo!");
            txtNome.requestFocus();
            return false;
        }
        if (txtUsuario.getText().trim().isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Preencha o nome de usuario!");
            txtUsuario.requestFocus();
            return false;
        }
        if (txtUsuario.getText().trim().length() < 3) 
        {
            JOptionPane.showMessageDialog(this, "Usuario deve ter pelo menos 3 caracteres!");
            txtUsuario.requestFocus();
            return false;
        }
        String senha = new String(txtSenha.getPassword());
        if (senha.isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Preencha a senha!");
            txtSenha.requestFocus();
            return false;
        }
        if (senha.length() < 3) 
        {
            JOptionPane.showMessageDialog(this, "Senha deve ter pelo menos 3 caracteres!");
            txtSenha.requestFocus();
            return false;
        }
        return true;
    }
    
    // Main para testar (opcional)
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        { 
            public void run() 
            {
                new TelaCadastroUsuario().setVisible(true);
            }
        });
    }
}

