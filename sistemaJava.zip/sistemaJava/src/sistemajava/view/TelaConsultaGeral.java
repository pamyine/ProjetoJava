package sistemajava.view;

import sistemajava.dao.*;
import sistemajava.modelo.*;
import sistemajava.view.TelaInicio;
import sistemajava.view.TelaCadastroUsuario;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sistemajava.view.TelaPrincipal;

public class TelaConsultaGeral extends JFrame 
{
    
    // Componentes
    private JComboBox<String> cbTipo;
    private JButton btnConsultar;
    private JButton btnCadastrarUsuario;
    private JButton btnVoltar;
    private JTable tblDados;
    private JScrollPane scrollPane;
    private JLabel lblTotal;
    
    // DAOs
    private UsuarioDAO usuarioDAO;
    private ProfessorDAO professorDAO;
    private AlunoDAO alunoDAO;
    private FaculdadeDAO faculdadeDAO;
    
    // Construtor
    public TelaConsultaGeral() 
    {
        usuarioDAO = new UsuarioDAO();
        professorDAO = new ProfessorDAO();
        alunoDAO = new AlunoDAO();
        faculdadeDAO = new FaculdadeDAO();
        initComponents();
    }
    
    // Criar e configurar componentes
    private void initComponents() 
    {
        setTitle("Consulta Geral");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        JLabel lblTitulo = new JLabel("CONSULTA GERAL DO SISTEMA");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setBounds(350, 20, 350, 30);
        add(lblTitulo);
        
        JLabel lblSelecione = new JLabel("Selecione o que deseja consultar:");
        lblSelecione.setBounds(30, 70, 250, 25);
        add(lblSelecione);
        
        cbTipo = new JComboBox<String>(new String[]
        {
            "Selecione...",
            "Usuarios",
            "Professores",
            "Alunos",
            "Faculdades"
        });
        cbTipo.setBounds(280, 70, 200, 25);
        add(cbTipo);
        
        btnConsultar = new JButton("Consultar");
        btnConsultar.setBounds(490, 70, 120, 25);
        btnConsultar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnConsultarActionPerformed();
            }
        });
        add(btnConsultar);
        
        btnCadastrarUsuario = new JButton("Cadastrar Usuario");
        btnCadastrarUsuario.setBounds(30, 110, 160, 30);
        btnCadastrarUsuario.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnCadastrarUsuarioActionPerformed();
            }
        });
        add(btnCadastrarUsuario);
        
        btnVoltar = new JButton("Voltar");
        btnVoltar.setBounds(200, 110, 100, 30);
        btnVoltar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                btnVoltarActionPerformed();
            }
        });
        add(btnVoltar);
        
        lblTotal = new JLabel("Total de registros: 0");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 12));
        lblTotal.setBounds(30, 150, 300, 25);
        add(lblTotal);
        
        DefaultTableModel modelo = new DefaultTableModel(new String[]{}, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        tblDados = new JTable(modelo);
        scrollPane = new JScrollPane(tblDados);
        scrollPane.setBounds(30, 180, 930, 360);
        add(scrollPane);
    }
    
    private void btnConsultarActionPerformed() 
    {
        String tipoSelecionado = (String) cbTipo.getSelectedItem();
        
        if (tipoSelecionado.equals("Selecione...")) 
        {
            JOptionPane.showMessageDialog(this, "Selecione um tipo para consultar!");
            return;
        }
        
        if (tipoSelecionado.equals("Usuarios")) 
        {
            consultarUsuarios();
        } 
        else if (tipoSelecionado.equals("Professores")) 
        {
            consultarProfessores();
        } 
        else if (tipoSelecionado.equals("Alunos")) 
        {
            consultarAlunos();
        } 
        else if (tipoSelecionado.equals("Faculdades")) 
        {
            consultarFaculdades();
        }
    }
    
    private void consultarUsuarios() 
    {
        String[] colunas = {"ID", "Nome", "Usuario", "Tipo"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        List<Usuario> lista = usuarioDAO.listarTodos();
        
        for (Usuario u : lista) 
        {
            modelo.addRow(new Object[]{
                u.getId(),
                u.getNome(),
                u.getUsuario(),
                u.getTipo()
            });
        }
        
        tblDados.setModel(modelo);
        lblTotal.setText("Total de registros: " + lista.size());
    }
    
    private void consultarProfessores() 
    {
        String[] colunas = {"ID", "Nome", "CPF", "Email", "Titulacao", "Area Atuacao", "Telefone", "Faculdade"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        List<Professor> lista = professorDAO.listarTodos();
        
        for (Professor p : lista) 
        {
            modelo.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                p.getCpf(),
                p.getEmail(),
                p.getTitulacao(),
                p.getAreaAtuacao(),
                p.getTelefone(),
                p.getNomeFaculdade()
            });
        }
        
        tblDados.setModel(modelo);
        lblTotal.setText("Total de registros: " + lista.size());
    }
    
    private void consultarAlunos() 
    {
        String[] colunas = {"ID", "Nome", "CPF", "Email", "Curso", "Telefone", "Data Nasc", "Faculdade"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        List<Aluno> lista = alunoDAO.listarTodos();
        
        for (Aluno a : lista) 
        {
            modelo.addRow(new Object[]{
                a.getId(),
                a.getNome(),
                a.getCpf(),
                a.getEmail(),
                a.getCurso(),
                a.getTelefone(),
                a.getDataNascimento(),
                a.getNomeFaculdade()
            });
        }
        
        tblDados.setModel(modelo);
        lblTotal.setText("Total de registros: " + lista.size());
    }
    
    private void consultarFaculdades() 
    {
        String[] colunas = {"ID", "Nome", "CNPJ", "Endereco", "Telefone", "Email"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) 
        {
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };
        
        List<Faculdade> lista = faculdadeDAO.listarTodas();
        
        for (Faculdade f : lista) 
        {
            modelo.addRow(new Object[]{
                f.getId(),
                f.getNome(),
                f.getCnpj(),
                f.getEndereco(),
                f.getTelefone(),
                f.getEmail()
            });
        }
        
        tblDados.setModel(modelo);
        lblTotal.setText("Total de registros: " + lista.size());
    }
    
    private void btnCadastrarUsuarioActionPerformed() 
    {
        TelaCadastroUsuario telaCadastro = new TelaCadastroUsuario();
        telaCadastro.setVisible(true);
        this.dispose();
    }
    
    private void btnVoltarActionPerformed() 
    {
        TelaPrincipal principal = new TelaPrincipal();
        principal.setVisible(true);
        this.dispose();
    }
    
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new TelaConsultaGeral().setVisible(true);
            }
        });
    }
}