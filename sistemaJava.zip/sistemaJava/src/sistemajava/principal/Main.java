package sistemajava.principal;

import sistemajava.view.TelaInicio;

public class Main {
    
    public static void main(String[] args) {
        // Abrir a tela de início
        TelaInicio tela = new TelaInicio();
        tela.setVisible(true);
        tela.setLocationRelativeTo(null);
    }
}