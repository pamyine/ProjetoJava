package sistemajava.dao;

import sistemajava.modelo.Professor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProfessorDAO 
{
    
    
    public boolean inserir(Professor professor) 
    
    {
        Connection conexao = ConexaoDB.conectar();
        
        try {
            String sql = "INSERT INTO professores (nome, cpf, email, titulacao, area_atuacao, data_nascimento, telefone, id_faculdade) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getCpf());
            stmt.setString(3, professor.getEmail());
            stmt.setString(4, professor.getTitulacao());
            stmt.setString(5, professor.getAreaAtuacao());
            stmt.setString(6, professor.getDataNascimento());
            stmt.setString(7, professor.getTelefone());
            stmt.setInt(8, professor.getIdFaculdade());
            
            stmt.executeUpdate();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir professor: " + e.getMessage());
            return false;
        }
    
    }
    
    /**
     * Listar todos os professores com o nome da faculdade
     */
    public List<Professor> listarTodos() 
    {
        List<Professor> lista = new ArrayList<>();
        Connection conexao = ConexaoDB.conectar();
        
        try {
            String sql = "SELECT p.*, f.nome as nome_faculdade " +
                        "FROM professores p " +
                        "LEFT JOIN faculdades f ON p.id_faculdade = f.id " +
                        "ORDER BY p.nome";
            
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Professor p = new Professor();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                p.setEmail(rs.getString("email"));
                p.setTitulacao(rs.getString("titulacao"));
                p.setAreaAtuacao(rs.getString("area_atuacao"));
                p.setDataNascimento(rs.getString("data_nascimento"));
                p.setTelefone(rs.getString("telefone"));
                p.setIdFaculdade(rs.getInt("id_faculdade"));
                p.setNomeFaculdade(rs.getString("nome_faculdade"));
                
                lista.add(p);
            }
            
            rs.close();
            stmt.close();
            ConexaoDB.desconectar(conexao);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar professores: " + e.getMessage());
        }
        
        return lista;
    }
    public boolean atualizar(Professor professor) {
    Connection conexao = ConexaoDB.conectar();
    
    try {
        String sql = "UPDATE professores SET nome=?, cpf=?, email=?, titulacao=?, area_atuacao=?, data_nascimento=?, telefone=?, id_faculdade=? WHERE id=?";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        
        stmt.setString(1, professor.getNome());
        stmt.setString(2, professor.getCpf());
        stmt.setString(3, professor.getEmail());
        stmt.setString(4, professor.getTitulacao());
        stmt.setString(5, professor.getAreaAtuacao());
        stmt.setString(6, professor.getDataNascimento());
        stmt.setString(7, professor.getTelefone());
        stmt.setInt(8, professor.getIdFaculdade());
        stmt.setInt(9, professor.getId());
        
        stmt.executeUpdate();
        stmt.close();
        ConexaoDB.desconectar(conexao);
        
        return true;
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Erro ao atualizar professor: " + e.getMessage());
        return false;
    }
}

/**
 * Excluir professor
 */
    public boolean excluir(int id) {
    Connection conexao = ConexaoDB.conectar();
    
    try {
        String sql = "DELETE FROM professores WHERE id=?";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setInt(1, id);
        
        stmt.executeUpdate();
        stmt.close();
        ConexaoDB.desconectar(conexao);
        
        return true;
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir professor: " + e.getMessage());
        return false;
    }
}
}